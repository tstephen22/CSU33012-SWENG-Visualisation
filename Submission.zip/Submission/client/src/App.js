import { useState, useEffect } from 'react';
import './App.css';
import './index.css'
import { Area, AreaChart, LineChart, Line, CartesianGrid, XAxis, YAxis, Tooltip, Legend, ResponsiveContainer, ReferenceLine, Label } from 'recharts';
import { Pie, Cell, PieChart } from 'recharts';
import * as React from "react"; 
import Container from '@mui/material/Container';
import CssBaseline from '@mui/material/CssBaseline';
import Box from '@mui/material/Box';
import { makeStyles } from '@mui/material';
import { Button, ToggleButton, TextField, CircularProgress } from '@mui/material';
import {Tooltip as MaterialTooltip } from '@mui/material';
import BugReportIcon from '@mui/icons-material/BugReport';
import SendIcon from '@mui/icons-material/Send';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { ClassNames } from '@emotion/react';

 function App() {
   //GET INFORMATION-------------------------------------------------
   const [responseData, setResponseData] = useState([{}])
   async function SendSubmission(send){
      return fetch("/add",{
          'method':'POST',
          'mode' : 'cors',
          headers : {
          'Content-Type':'application/json',
          'Accept': 'application/json'
      },
       body:JSON.stringify({send})
      })
      .then(response => response.json()).then(responseData => {
        setResponseData(responseData)
        if(responseData.response === "Repo error"){
          setRepoError(true)
          setRepoErrorText("Repository not found / inaccessible.")
          setLoading(false)
        } 
        else if (responseData.response === "Token error"){ 
          setAuthError(true)
          setAuthErrorText("Invalid token / Unaccessible token.")
          setLoading(false)
        } else if(responseData.response === "success"){ 
          window.location.reload(true);
          setLoading(false)
        }
        console.log(responseData)
      })
      .catch(error => console.log(error))
    }
  const [commitData, setCommitData] = useState([{}])
  const [authors, setAuthors] =  useState([{}])
  const [otherAuthors, setOtherAuthors] =  useState([{}])
  useEffect(() => {
    fetch("/commits").then(
      res => res.json() 
    ).then(
        data => {
          setCommitData(data)
          console.log(data)
        }
    )
    fetch("/authors").then(
      res2 => res2.json() 
    ).then(
        authors => {
          setAuthors(authors)
          console.log(authors)
        }
    )
    fetch("/other_authors").then(
      res3 => res3.json() 
    ).then(
        otherAuthors => {
          setOtherAuthors(otherAuthors)
          console.log(otherAuthors)
        }
    )
  }, [])

  const points = commitData.points  
  const authorDis = authors.points
  const otherAuthPoints = otherAuthors.points
  const avgCommitRate = Math.round(commitData.avgCommitRate)
  const totalCommits = commitData.TotalCommits
  //COMMIT BUTTONS CONSTS
  const [commitButton, setCommitButton] = React.useState(true);
  const [commitGraph, setCommitGraph] = React.useState(true); 

  const [totalIssButton, setTotalIssButton] = React.useState(false);
  const [issueTotal, setIssueTotal] = React.useState(false); 

  const [issActButton, setIssActButton] = React.useState(false);
  const [issueAcTotal, setIssueAcTotal] = React.useState(false);

  const [issClButton, setIssClButton] = React.useState(false);
  const [issueClTotal, setIssueClTotal] = React.useState(false);

  const [loading, setLoading] = React.useState(false);
  //PIE CHART BUTTON CONST
  const [otherPie, setOtherPie] = useState(false);
  //MISC
  const COLORS = ['#1B273E','#304670','#4B6DB0','#97ABD2'];
  const RADIAN = Math.PI / 180;
  //TEXT SUBMISSION CONSTS
  const [repo, setRepo] = useState('')
  const [repoError, setRepoError] = useState(false)
  const [repoErrorText, setRepoErrorText] = useState('')
  const [authKey, setAuthKey] = useState('')
  const [authError, setAuthError] = useState(false)
  const [authErrorText, setAuthErrorText] = useState('')
  //VARIOUS FUNCTIONS ------------------------------------------------------------
  
  const handleSubmit = (e) => {
   e.preventDefault()
   if(repo == '') {
     setRepoError(true) 
     setRepoErrorText("Entry needed.")
   }
   else setRepoError(false);
   if(authKey == '') { 
     setAuthError(true)
     setAuthErrorText("Entry needed.")
   }
   else setAuthError(false);
    if(repo && authKey) { 
      setLoading(true)
      setRepoError(false)
      setAuthError(false)
      console.log("Entered repo: " + repo)
      console.log("Entered authKey: " + authKey)
      SendSubmission({repo, authKey})
    }
  }

  const renderCustomizedLabel = ({
    cx, cy, midAngle, innerRadius, outerRadius, percent, index,
  }) => {

    const radius = innerRadius + (outerRadius - innerRadius) * 0.5;
    const x = cx + radius * Math.cos(-midAngle * RADIAN);
    const y = cy + radius * Math.sin(-midAngle * RADIAN);

   return (
     <text x={x} y={y} fill="white" textAnchor="middle" dominantBaseline="central">
      {(percent * 100).toFixed(0) > 10 ? `${(percent * 100).toFixed(0)}%` : ''}
     </text>
 );
}
  const CustomTooltip = ({ active, payload, nameKey }) => {
    if (active && payload && payload.length) {
      return (
        <div className="custom-tooltip">
          <Box sx={{backgroundColor:'#fff', padding: 1, stroke: '#e8e8e8'}}>
          <p className="author">Author: {`${payload[0].name}`}</p>
          <p className="commits">No. of Commits: {`${payload[0].value}`}</p>
          </Box>
        </div>
      );
    }

    return null;
  };
  const renderColorfulLegendText = (value, entry) => {
    const {dataKey} = entry
    var color1 = '#ffff'
    if(dataKey == 'Commit Rate') color1 = "#8884d8"
    else if(dataKey == 'Total Issue Count') color1 = "blue"
    else if(dataKey == 'Issues opened') color1 = "red"
    else if(dataKey == 'Issues closed') color1 = "green"
    return <span style={{color: color1}}>{value}</span>;
  };
//RENDERING-----------------------------------------------------------------------------------------------------------------------------------------------------------------------
  return (
    <>
    <ThemeProvider theme = {theme}>
      <CssBaseline />
      {/*TITLE AND SUBMISSION BUTTONS ------------------------------------------------ */ }
      <h2 className='container'><p className='Title'>Analytics for repository {commitData['Repository Name']}</p>
        <form className='Repo-Buttons' noValidate autoComplete='off' onSubmit={handleSubmit}>
        <TextField fullWidth
          onChange={(e) => setRepo(e.target.value)}
          InputProps={{
            className: 'text'
          }}
          label="Repository"
          color='secondary'
          sx={{paddingRight:3}}
          helperText={repoErrorText}
          required
          error={repoError}
          />
        <TextField fullWidth
          onChange={(e) => setAuthKey(e.target.value)}
          label="Authentication key"
          sx={{paddingRight:3}}
          color='secondary'
          InputProps={{
            className: 'text'
          }}
          helperText={authErrorText}
          required
          error={authError}
          />
          <Button type="submit" color='secondary' variant='contained' endIcon={<SendIcon /> } sx={{paddingRight:3, marginRight:3, marginTop:1, marginBottom:1}}>
          </Button>
        </form>
      </h2>
      <div class="container2">
      <div class="Commit-header"><p>Commit rate over time </p></div>
      <div class="Pie-header"><p>Breakdown of Committers -- Commit Total: {totalCommits}</p></div>
      <div class="loading">{loading && <CircularProgress />}</div>
      </div>
      {/*Graphs ------------------------------------------------ */ }
      <div className='Row'>
        <ResponsiveContainer width="60%" aspect={2}>
          <AreaChart
            width="100%"
            height={1000}
            data={points}
            margin={{
              top: 10,
              right: 30,
              left: 0,
              bottom: 0,
            }}
          >
            <XAxis dataKey="Date" stroke="white" />
            <YAxis stroke="white">
            <Label value="Count"  offset={20} position="top" fill='#ffff' />
              </YAxis>
            <Tooltip />
            {commitGraph && <Area type="monotone" dataKey='Commit Rate' stroke={theme.palette.primary} fill="#8884d8"/>}
            {commitGraph && <ReferenceLine y={commitData.avgCommitRate} label={{value: "Average rate: "+avgCommitRate, fill: '#29d7f1'}} stroke="#29d7f1" strokeDasharray="3 3" aria-label='' />}
            {issueTotal && <Area type="monotone" dataKey='Total Issue Count' stroke="deep blue" fillOpacity={0.6} fill="blue" />}
            {issueAcTotal && <Area type="monotone" dataKey='Issues opened' stroke="deep red" fillOpacity={0.6} fill="red" />}
            {issueClTotal && <Area type="monotone" dataKey='Issues closed' stroke="deep green" fillOpacity={0.6} fill="green" />}
  
            <Legend verticalAlign = 'top' align='center' height={36} formatter={renderColorfulLegendText} />
          </AreaChart>
        </ResponsiveContainer>
      {/*PIE CHART ------------------------------------------------ */ }
      <ResponsiveContainer width="60%" aspect={2}>
        <PieChart width={750} height={750}>
        <Pie data={authorDis} dataKey="count" isAnimationActive={false} nameKey="contributor" outerRadius="70%" fill="#8884d8" label={renderCustomizedLabel} labelLine={false} 
         margin = {{top: 10, left: 700 }}>
           {(authorDis || []).map((entry, index) => (
                <Cell className = "cell" key={`cell-${index}`} fill={COLORS[index % COLORS.length]} onClick={() => {if(index == 0) setOtherPie(!otherPie)}
                  } />
              ))}
         </Pie>
         {otherPie && <Pie data={otherAuthPoints} dataKey="count" nameKey="contributor" cx="50%" cy="50%" innerRadius="85%" outerRadius="100%" fill="#91a2c2" labelLine = {false}>
         {(otherAuthPoints || []).map((entry, index) => (
                <Cell className = "cell" key={`cell-${index}`}/>
              ))}
           </Pie>}
        <Tooltip content={CustomTooltip} />
        </PieChart>
      </ResponsiveContainer>
      </div>
      <div className='Row'>
       {/* Buttons  ------------------------------------------- */ }
       <MaterialTooltip title="Show commit rate">
        <ToggleButton
          value="check"
          selected={commitButton}
          
          onChange={() => {
            setCommitButton(!commitButton);
            setCommitGraph(!commitGraph);
          }}
          color='primary'
          sx = {{marginLeft : 8, marginTop: 3}}
        >
          <BugReportIcon color='purple' />
        </ToggleButton>
      </MaterialTooltip>
      <MaterialTooltip title="Show total issue count">
        <ToggleButton
          value="check"
          selected={totalIssButton}
          onChange={() => {
            setTotalIssButton(!totalIssButton);
            setIssueTotal(!issueTotal);
          }}
          color='primary'
          
          sx = {{marginLeft : 3, marginTop: 3}}
        >
          <BugReportIcon color='lightBlue' />
        </ToggleButton>
      </MaterialTooltip>
      <MaterialTooltip title="Show issues opened">
      <ToggleButton
        value="check"
        selected={issActButton}
        onChange={() => {
          setIssActButton(!issActButton);
          setIssueAcTotal(!issueAcTotal);
        }}
        color='primary'
        sx = {{marginLeft : 3, marginTop: 3}}
       >
        <BugReportIcon color='red' />
       </ToggleButton>
       </MaterialTooltip>
       <MaterialTooltip title="Show issues closed">
       <ToggleButton
        value="check"
        selected={issClButton}
        onChange={() => {
          setIssClButton(!issClButton);
          setIssueClTotal(!issueClTotal);
        }}
        color='primary'
        sx = {{marginLeft : 3, marginTop: 3}}
       >
         <BugReportIcon color='green' />
      </ToggleButton>
      </MaterialTooltip>
    </div>
    <div class="container3">
     <div class="Description">
     <p className='descText'>
         Metric Visualisation Project : CSU33012 2020
        </p>
       <p className='descText'>
         DESCRIPTION:
        </p>
        <p className='descText'>
         Graph -- <p className='nextLine'>Can display up to 4 separate visualisations over the lifetime of a repository (in months) -- Commit rate,
          total issue count for a month, total issues opened in a month and total issues closed in a month. Total issue count is (total issues opened in the month
          - total issues closed in the month). Click on each button to display the respective graph.
          </p>
        </p>
        <p className='descText'>
         Please feel free to make use of the entry boxes in the header to display the visualisation for other repositories. The visualisation is best suited 
         for repositories with total commits in the range of 300-4000. Repositories past this range may take longer than usual to process. There are example 
         repositories found in the examples.txt file for use. 
          </p>
      </div>
     <div class="PieChart-Help">
     < br />
     < br />
     < br />
        <p className='descText'>
          Pie Chart --
          <p className='nextLine'>
            Gives a breakdown of the contributors of the repository. Hover over any sector to see the author and the amount of 
            commits they have contributed to the repository. For larger repos, click on the 'Others' sector to see
            a breakdown of smaller contributors (contributors who have made 5 or less commits).

          </p>
          </p>
     </div>
     <div class="Author">
     <p className='signOff'>Theo Stephens Kehoe</p>
     </div>
     <div class="Student-No">
     <p className='studentNo'>Student No: 19334945</p>
     </div>
    </div>
    </ThemeProvider>
    </>
  );
}
const theme = createTheme ({
  palette: {
    type: 'dark',
    primary: {
      main: '#29d7f1',
    },
    secondary: {
      main: '#f48fb1',
    },
    background: {
      default: '#212121',
      paper: '#424242',
    },
    purple: {
      main: "#8884d8",
    },
    red: {
      main: 'red',
    },
    green: {
      main: 'green',
    },
    lightBlue: {
      main: '#add8e6',
    },
    white: { 
      main: 'white',
    }
  }
});
export default App;